#ifndef _EDK2_COMPAT_H_
#define _EDK2_COMPAT_H_

/*
 * EDK2 Compatibility Layer for tinyprintf
 * Replaces CRT headers (stddef.h, stdarg.h) removed from modern EDK2
 */

#include <Library/BaseLib.h>

/* size_t is architecture-dependent unsigned integer in EDK2 */
#ifndef _SIZE_T_DEFINED
#define _SIZE_T_DEFINED
typedef UINTN size_t;
#endif

/* va_list and variadic macros from EDK2 BaseLib */
#ifndef _VA_LIST_DEFINED
#define _VA_LIST_DEFINED
typedef VA_LIST va_list;
#endif

#define va_start(ap, v)  VA_START(ap, v)
#define va_end(ap)       VA_END(ap)
#define va_arg(ap, type) VA_ARG(ap, type)

#endif /* _EDK2_COMPAT_H_ */
